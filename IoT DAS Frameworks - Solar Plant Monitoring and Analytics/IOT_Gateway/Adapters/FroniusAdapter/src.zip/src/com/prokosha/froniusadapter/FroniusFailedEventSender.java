/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prokosha.froniusadapter;

import com.prokosha.froniusadapter.configuration.AdapterProperties;
import com.prokosha.ssl.tcp.SSLClient;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author naveen
 */
public class FroniusFailedEventSender {
    
    private static Logger logger = Logger.getLogger(FroniusFailedEventSender.class.getName());
    private static Logger evtIdLogger = Logger.getLogger("eventsIdLogger");
    private String propertyFile;
    public static SSLClient FrontControllerSSLClient = null;
    public static SSLClient WatchDogEventConnector = null;
    public static String failedevents = null;
    
    public FroniusFailedEventSender(String propertyFileName) {
        logger.debug("Constructing  FroniusAdapter of FroniusFailedEventSender...");
        this.propertyFile = propertyFileName;
    }
    
    public boolean initialize() {
        logger.debug("Loading FroniusAdapter properties from property file: " + propertyFile);
        try {
            if (!AdapterProperties.loadProperties(propertyFile)) {
                logger.error("*** ERROR *** Coould not load the adapter properties in FroniusFailedEventSender correctly...");
                return false;
                
            }
            if (!FroniusMailModule.initialize()) {
                logger.error("*** ERROR *** Coould not initialize FroniusMailModule in FroniusFailedEventSender correctly...");
                return false;
            }
            logger.debug("FroniusAdapter properties in FroniusFailedEventSender, FroniusEventMapper and requests configuration loaded successfully!!");
            return true;
            
        } catch (Exception ex) {
            logger.error("*** ERROR **** error while loading adapter properties and requests configuration: \n" + ex);
            logger.error("Send msg and e-mail");
            FroniusMailModule.sendSMS("Fronius Error while loading adapter properties and "
                    + "requests configuration in FroniusFailedEventSender " + ex.toString());
            
            String szSubject = "FroniusAdapterError";
            String szBody = "Fronius Error while loading adapter properties and requests configuration"
                    + ex.toString();
            FroniusMailModule.sendMail(szSubject, szBody);
            
            ex.printStackTrace();
            return false;
        }
        
    }
    
    public void mainLoop() {
        
        logger.debug("Entering FroniusFailedEventSender mainloop...");
        FrontControllerSSLClient = new SSLClient();
        //set up the FrontController connector to package and send CEP events
        FrontControllerSSLClient.initialize(AdapterProperties.getSSLHost(), AdapterProperties.getSSLPort(), AdapterProperties.getNewline());
        
        if (AdapterProperties.sendToWatchDog()) {
            WatchDogEventConnector = new SSLClient();
            WatchDogEventConnector.initialize(AdapterProperties.getWatchDogHost(), AdapterProperties.getWatchDogPort(), AdapterProperties.getNewline());
        }
        
        logger.debug("Connecting to FrontController....");
        
        if (!FrontControllerSSLClient.isServerReady()) {
            logger.error("Some error occurred in FroniusFailedEventSender while connecting to FrontController. Will retry later...");
        }
        //reading file from adopter properties
        failedevents = AdapterProperties.getFailedEventsLog();
        FileReader failedFile = null;
        BufferedReader failedBReader = null;
        String failedFileLine = null;
        boolean evntSent = false;
        boolean found = false;
        String eventId = null;
        String[] splite = null;
        String[] spliteEquals = null;
        FileReader filedIdFile = null;
        BufferedReader failedIdBReader = null;
        String eventLine = null;
        String EvtString = null;
        
        try {
            logger.info("FailedEvents read from file==>>" + failedevents);
            //Create object of FileReader
            failedFile = new FileReader(failedevents);
            //Instantiate the BufferedReader Class
            failedBReader = new BufferedReader(failedFile);
            // Read file line by line and print on the console
            while ((failedFileLine = failedBReader.readLine()) != null) {
                
                logger.info("line=====>" + failedFileLine);
                //splitting String to get eventId
                if (failedFileLine.contains("=")) {
                    spliteEquals = failedFileLine.split("=");
                    for (int i = 0; i < spliteEquals.length; i++) {
                        
                        if (spliteEquals[i].contains("eventID")) {
                            splite = spliteEquals[i + 1].split(",");
                            eventId = splite[0];
                        }
                    }
                    eventId = "id:" + eventId;
                    logger.info("event id====>" + eventId);
                    //reading the eventId log file
                    filedIdFile = new FileReader("eventidlog/froniuseventid.log");
                    
                    failedIdBReader = new BufferedReader(filedIdFile);

                    //froniuseventid.log fie must contain atleast one space or else while condition will not execute

                    while ((eventLine = failedIdBReader.readLine()) != null) {
                        int indexFound = eventLine.indexOf(eventId);
                        if (indexFound > -1) {
                            found = true;
                            logger.info("eventid found in eventIDlog file");
                        } else {
                            logger.info("eventid not found in eventIDlog file");
                        }
                    }
                    
                    if (found != true) {
                        EvtString = failedFileLine.substring(47);
                        logger.info("Sending CEP event from FailedEventSender ==>>");
                        evntSent = FrontControllerSSLClient.sendMessage(EvtString);
                    }
                    found = false;
                    //logger.info("File returnig from frontcontroller "+evntSent);
                    if (evntSent) {
                        logger.info("frontcontroller event sent successfully from FroniusFailedEventSender");
                        evtIdLogger.info(eventId);
                        logger.info("event id writing in to eventID log file");
                        
                    }
                    if (!evntSent) {
                        logger.info("frontcontroller event not sent, logging the event to send later from FroniusFailedEventSender");
                        
                    }
                    //Close the buffer reader
                    filedIdFile.close();
                    failedIdBReader.close();
                }
                
            }
            //Close the buffer reader
            failedBReader.close();
            failedFile.close();
        } catch (Exception e) {
            logger.info("Error while reading file line by line in FroniusFailedEventSender :"
                    + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (FrontControllerSSLClient != null) {
                    FrontControllerSSLClient = null;
                } else if (WatchDogEventConnector != null) {
                    WatchDogEventConnector = null;
                } else if (failedevents != null) {
                    failedevents = null;
                } else if (failedFile != null) {
                    failedFile.close();
                    failedFile = null;
                } else if (failedBReader != null) {
                    failedBReader.close();
                    failedBReader = null;
                } else if (failedFileLine != null) {
                    failedFileLine = null;
                } else if (eventId != null) {
                    eventId = null;
                } else if (splite != null) {
                    splite = null;
                } else if (spliteEquals != null) {
                    spliteEquals = null;
                } else if (filedIdFile != null) {
                    filedIdFile.close();
                    filedIdFile = null;
                } else if (failedIdBReader != null) {
                    failedIdBReader.close();
                    failedIdBReader = null;
                } else if (eventLine != null) {
                    eventLine = null;
                } else if (EvtString != null) {
                    EvtString = null;
                }
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e);
            }
            
        }
        
    }
    
    public static void main(String[] args) {

        //setup the logger properties
        PropertyConfigurator.configure("config" + File.separator + "logger.properties");
        //TODO: pass the property file name as a program argument
        FroniusFailedEventSender fronius = new FroniusFailedEventSender("config" + File.separator + "froniusadapter.properties");
        if (fronius.initialize()) {
            fronius.mainLoop();
        } else {
            logger.error("Could not start Fronius adapter in FroniusFailedEventSender properly. Exiting.....");
            System.exit(1);
        }
    }
}
