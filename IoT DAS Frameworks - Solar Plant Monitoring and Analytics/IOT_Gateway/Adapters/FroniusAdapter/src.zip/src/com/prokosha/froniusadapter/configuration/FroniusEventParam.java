/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.prokosha.froniusadapter.configuration;

/**
 *
 * @author rekhas
 */
public class FroniusEventParam {

    private String eventField = null;
    private String froField = null;
    private String froValue = null;
    private String froUnit = null;
    private String dataType = null;

    public FroniusEventParam(String szEvtField, String szFroName, String szFroValue, String szFroUnit, String szEvtType) {
        this.eventField = szEvtField;
        this.froField = szFroName;
        this.froValue = szFroValue;
        this.froUnit = szFroUnit;
        this.dataType = szEvtType;
    }

    public String getEventField() {
        return eventField;
    }

    public String getFroField() {
        return froField;
    }

    public String getFroValue() {
        return froValue;
    }

    public String getFroUnit() {
        return froUnit;
    }

    public String getDataType() {
        return dataType;
    }

    public String toString() {
        return "eventField=" + eventField + ",froField=" + froField + ",froValue=" + froValue + ",froUnit=" + froUnit + ",dataType=" + dataType;
    }
}
